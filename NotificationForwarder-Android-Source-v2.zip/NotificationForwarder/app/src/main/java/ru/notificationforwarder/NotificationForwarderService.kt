package ru.notificationforwarder

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class NotificationForwarderService : NotificationListenerService() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Не пересылаем собственные уведомления приложения.
        if (sbn.packageName == packageName) return

        val prefs = getSharedPreferences("forwarder", MODE_PRIVATE)
        val token = prefs.getString("bot_token", "").orEmpty()
        val chatId = prefs.getString("chat_id", "").orEmpty()
        if (token.isBlank() || chatId.isBlank()) return

        // Исключения применяются по точному package name.
        val excludedPackages = prefs.getString("excluded_packages", "").orEmpty()
            .split(',', '\\n', ';', ' ')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()
        if (sbn.packageName in excludedPackages) return

        val extras = sbn.notification.extras
        val appName = try {
            val appInfo = packageManager.getApplicationInfo(sbn.packageName, 0)
            packageManager.getApplicationLabel(appInfo).toString()
        } catch (_: Exception) {
            sbn.packageName
        }

        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val description = extras.getCharSequence("android.text")?.toString()
            ?: extras.getCharSequence("android.bigText")?.toString().orEmpty()

        if (title.isBlank() && description.isBlank()) return

        val message = buildString {
            append("📱 Приложение: ").append(appName).append('\\n')
            append("📦 Package: ").append(sbn.packageName).append('\\n')
            if (title.isNotBlank()) append("📝 Заголовок: ").append(title).append('\\n')
            if (description.isNotBlank()) append("💬 Описание: ").append(description)
        }

        executor.execute { sendToTelegram(token, chatId, message) }
    }

    private fun sendToTelegram(token: String, chatId: String, message: String) {
        var connection: HttpURLConnection? = null
        try {
            val url = URL("https://api.telegram.org/bot$token/sendMessage")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 15000
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            }

            val body = "chat_id=${enc(chatId)}&text=${enc(message)}"
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            if (code !in 200..299) {
                val error = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                Log.e("NotificationForwarder", "Telegram API error $code: $error")
            }
        } catch (e: Exception) {
            Log.e("NotificationForwarder", "Failed to send notification", e)
        } finally {
            connection?.disconnect()
        }
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
