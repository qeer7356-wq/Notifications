package ru.notificationforwarder

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("forwarder", MODE_PRIVATE) }
    private lateinit var tokenInput: EditText
    private lateinit var chatInput: EditText
    private lateinit var excludedInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 24)
        }

        fun addText(value: String, size: Float = 16f) {
            layout.addView(TextView(this).apply {
                text = value
                textSize = size
                setPadding(0, 10, 0, 10)
            })
        }

        fun addField(hint: String, value: String, isSecret: Boolean = false): EditText {
            return EditText(this).also { field ->
                field.hint = hint
                field.setText(value)
                if (isSecret) field.inputType = 129
                layout.addView(
                    field,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
        }

        addText("Notification Forwarder", 22f)
        addText("Пересылает уведомления в Telegram. Исключённые приложения не пересылаются.")
        tokenInput = addField("Bot Token", prefs.getString("bot_token", "") ?: "", true)
        chatInput = addField("Chat ID", prefs.getString("chat_id", "") ?: "")

        addText("Исключённые приложения", 18f)
        addText("Укажите package name приложений, уведомления которых НЕ нужно пересылать. Можно вводить по одному на строку или через запятую. Например: com.whatsapp")
        excludedInput = addField(
            "com.example.app\\ncom.example.secondapp",
            prefs.getString("excluded_packages", "") ?: ""
        ).apply {
            minLines = 3
            maxLines = 8
            gravity = android.view.Gravity.TOP
        }

        layout.addView(Button(this).apply {
            text = "Сохранить настройки"
            setOnClickListener {
                prefs.edit()
                    .putString("bot_token", tokenInput.text.toString().trim())
                    .putString("chat_id", chatInput.text.toString().trim())
                    .putString("excluded_packages", excludedInput.text.toString())
                    .apply()
                Toast.makeText(this@MainActivity, "Настройки сохранены", Toast.LENGTH_SHORT).show()
            }
        })

        layout.addView(Button(this).apply {
            text = "Открыть доступ к уведомлениям"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        })

        addText("Как узнать package name: откройте сведения о приложении в Android или посмотрите его идентификатор в ссылке Google Play. Пустой список означает, что пересылаются уведомления всех приложений (кроме самого Notification Forwarder).")
        setContentView(layout)
    }
}
